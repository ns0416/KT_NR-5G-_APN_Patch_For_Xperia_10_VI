# MagiskModule-Enable KT NR

## Description
Enable APN Update For KT NR(5G) on Xperia 10 VI
## Requirements
* KT LTE/NR SIM
* Magisk 17+
## Changelog
* v1 First Release
## Version Status
* Stable
```diff
+ Daily Use
```
## Test Cases
* KT LTE USIM